int f1(int a, int b);
int f2(char a, float x);
float f3(int x, int y);
int f21(int a, int b);
int f22(char a, float x);
float f23(int x, int y);
int f222(char a, float x);

int func(int x)
{
	int m;
	//abcdefg 
	int f1(int x, int m);
	float n;
	float mm;
	double theBoys;

	return m;
}

int f2(char a, float x)
{
	int m;
	int f1(int x, int m);
	//m = func(x);
}

int fnatic(char tes)
{
	double knight;
	int jackey;
	char karsa;
}

//栈溢出：7.cpp
//堆溢出：8.cpp
//宽度：b2.cpp
//运算：b3.cpp
//符号：b4.cpp
//格式化：r5.cpp

//样本库！！！！

//50个样本(每个100行以上)每10个为相似的一组，1分，最高5分

//漏洞检测与同源性检测样本库，样本数量不少于10个，
//每个代码行数不少于100行；每种漏洞至少一个。

float f3(int x, int y)
{
	int m;
	char n;
	x = x * y;
	y = y + y;
	int f2(char a, float x);
	int f1(int x, int m);
}

int func2(int x)
{
	int m;
	//abcdefg 
	int f21(int x, int m);
	//lalalalalalalal
	//aaaaaaaaaaaaaaaaa
	//Liiiiiiiiiiiiiiii
	//Saaaaaaaaaaaaaaa
	//Lalisa
	return m;
}

int f22(char a, float x)
{
	int m;
	int f21(int x, int m);
	x = x * y;
	y = y + y;
	//m = func(x);
}

//栈溢出：7.cpp
//堆溢出：8.cpp
//宽度：b2.cpp
//运算：b3.cpp
//符号：b4.cpp
//格式化：r5.cpp

//样本库！！！！

//50个样本(每个100行以上)每10个为相似的一组，1分，最高5分

//漏洞检测与同源性检测样本库，样本数量不少于10个，
//每个代码行数不少于100行；每种漏洞至少一个。

float f23(int x, int y)
{
	int m;
	char n;
	x = x * y;
	y = y + y;
	int f22(char a, float x);
	int f21(int x, int m);
}

//What can we say
//But I don’t care I’ll do it over and over

int f222(char a, float x)
{
	int m;
	x = x * y;
	y = y + y;
	int f1(int x, int m);
	//m = func(x);
}